# API Dario Joana Projeto Final

Projeto final de criação de uma API REST em .NET 8, consumida por website ou aplicação móvel, com PostgreSQL, Redis, Polly, JWT, Swagger, Mountebank e Docker Compose.

## Tecnologias usadas

- ASP.NET Core Web API (.NET 8)
- Entity Framework Core
- PostgreSQL
- Redis
- Polly
- Mountebank
- JWT
- Swagger / OpenAPI
- Docker Compose
- Postman

## Estrutura do repositório

```text
api-dariojoana-projeto-final/
├── api/
│   ├── ApiDarioJoanaProjetoFinal.sln
│   ├── ApiDarioJoanaProjetoFinal/
│   │   ├── Controllers/
│   │   ├── Models/
│   │   ├── Data/
│   │   ├── Services/
│   │   ├── Cache/
│   │   ├── Resilience/
│   │   ├── Dtos/
│   │   ├── Program.cs
│   │   ├── appsettings.json
│   │   └── Dockerfile
│   └── Tests/
├── database/
│   ├── schema.sql
│   └── seed.sql
├── imposter/
│   └── mountebank.json
├── postman/
│   └── ApiDarioJoanaProjetoFinal.postman_collection.json
├── docker-compose.yml
└── .env.example
```

## Como executar

Na raiz do projeto:

```bash
docker compose up --build
```

Depois de todos os serviços iniciarem, abrir:

```text
http://localhost:8080/swagger
```

## Serviços disponíveis

| Serviço | Porta |
|---|---:|
| API | 8080 |
| PostgreSQL | 5432 |
| Redis | 6379 |
| Mountebank | 2525 |

## Utilizador inicial

O ficheiro `database/seed.sql` cria automaticamente este utilizador quando o PostgreSQL arranca pela primeira vez.

```text
Email: admin@projeto.pt
Password: Admin123!
Role: Admin
```

## Endpoints principais

### Autenticação

```http
POST /api/auth/register
POST /api/auth/login
```

### Produtos

```http
GET /api/products
GET /api/products/{id}
POST /api/products
PUT /api/products/{id}
DELETE /api/products/{id}
```

Os métodos `POST`, `PUT` e `DELETE` exigem token JWT com role `Admin`.

### Utilizadores

```http
GET /api/users
GET /api/users/{id}
DELETE /api/users/{id}
```

Estes endpoints exigem token JWT com role `Admin`.

### Imposter externo

```http
GET /api/inventory/{sku}
POST /api/payments
```

Estes endpoints exigem autenticação JWT.

## Fluxo de cache

1. A API recebe o pedido.
2. Verifica a cache local em memória.
3. Se não existir, verifica Redis.
4. Se não existir, consulta PostgreSQL.
5. Guarda novamente em Redis e em cache local.
6. Devolve JSON ao cliente.

## Fluxo de resiliência com Polly

A API comunica com o Mountebank através de `HttpClient`.

Foram configurados:

- retry automático;
- circuit breaker;
- fallback simples no serviço externo.

## Testes com Postman

Importar a coleção:

```text
postman/ApiDarioJoanaProjetoFinal.postman_collection.json
```

Passos sugeridos:

1. Fazer login com o utilizador admin.
2. Copiar o token recebido.
3. Colocar o token na variável `token` da coleção.
4. Testar produtos, inventário e pagamentos.

## Observação importante

Este projeto está preparado como base funcional para a entrega. Antes da submissão, convém testar localmente com Docker e confirmar se o Swagger abre corretamente.
