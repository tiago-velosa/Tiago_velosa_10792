namespace ApiDarioJoanaProjetoFinal.Tests.UnitTests;

public class SimpleTests
{
    [Fact]
    public void Project_Should_Run_Basic_Test()
    {
        Assert.True(true);
    }
}
