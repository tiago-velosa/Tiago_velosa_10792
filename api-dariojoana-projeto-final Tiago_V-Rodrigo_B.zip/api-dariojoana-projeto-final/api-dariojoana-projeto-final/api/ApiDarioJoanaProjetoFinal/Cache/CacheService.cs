using Microsoft.Extensions.Caching.Memory;
using StackExchange.Redis;
using System.Text.Json;

namespace ApiDarioJoanaProjetoFinal.Cache;

public interface ICacheService
{
    Task<T?> GetAsync<T>(string key);
    Task SetAsync<T>(string key, T value, TimeSpan redisDuration, TimeSpan localDuration);
    Task RemoveAsync(string key);
}

public class CacheService(IMemoryCache memoryCache, IConnectionMultiplexer redis) : ICacheService
{
    private readonly IDatabase _redisDb = redis.GetDatabase();

    public async Task<T?> GetAsync<T>(string key)
    {
        if (memoryCache.TryGetValue(key, out T? localValue))
            return localValue;

        var redisValue = await _redisDb.StringGetAsync(key);

        if (!redisValue.HasValue)
            return default;

        var value = JsonSerializer.Deserialize<T>(redisValue!);

        if (value is not null)
            memoryCache.Set(key, value, TimeSpan.FromSeconds(30));

        return value;
    }

    public async Task SetAsync<T>(string key, T value, TimeSpan redisDuration, TimeSpan localDuration)
    {
        memoryCache.Set(key, value, localDuration);

        var json = JsonSerializer.Serialize(value);
        await _redisDb.StringSetAsync(key, json, redisDuration);
    }

    public async Task RemoveAsync(string key)
    {
        memoryCache.Remove(key);
        await _redisDb.KeyDeleteAsync(key);
    }
}
