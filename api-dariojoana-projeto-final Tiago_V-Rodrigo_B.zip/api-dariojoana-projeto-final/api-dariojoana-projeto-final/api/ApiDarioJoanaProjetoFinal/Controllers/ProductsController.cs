using ApiDarioJoanaProjetoFinal.Cache;
using ApiDarioJoanaProjetoFinal.Data;
using ApiDarioJoanaProjetoFinal.Dtos;
using ApiDarioJoanaProjetoFinal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiDarioJoanaProjetoFinal.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController(AppDbContext db, ICacheService cache) : ControllerBase
{
    private const string ProductsCacheKey = "products:all";

    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<IEnumerable<Product>>> GetAll()
    {
        var cached = await cache.GetAsync<List<Product>>(ProductsCacheKey);
        if (cached is not null)
            return Ok(cached);

        var products = await db.Products
            .AsNoTracking()
            .Where(p => p.IsActive)
            .OrderBy(p => p.Id)
            .ToListAsync();

        await cache.SetAsync(ProductsCacheKey, products, TimeSpan.FromMinutes(10), TimeSpan.FromSeconds(30));

        return Ok(products);
    }

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    public async Task<ActionResult<Product>> GetById(int id)
    {
        var cacheKey = $"products:{id}";
        var cached = await cache.GetAsync<Product>(cacheKey);

        if (cached is not null)
            return Ok(cached);

        var product = await db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);

        if (product is null)
            return NotFound();

        await cache.SetAsync(cacheKey, product, TimeSpan.FromMinutes(10), TimeSpan.FromSeconds(30));

        return Ok(product);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<ActionResult<Product>> Create(ProductCreateDto dto)
    {
        var product = new Product
        {
            Sku = dto.Sku,
            Name = dto.Name,
            Description = dto.Description,
            Price = dto.Price
        };

        db.Products.Add(product);
        await db.SaveChangesAsync();
        await cache.RemoveAsync(ProductsCacheKey);

        return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, ProductUpdateDto dto)
    {
        var product = await db.Products.FindAsync(id);

        if (product is null)
            return NotFound();

        product.Name = dto.Name;
        product.Description = dto.Description;
        product.Price = dto.Price;
        product.IsActive = dto.IsActive;

        await db.SaveChangesAsync();
        await cache.RemoveAsync(ProductsCacheKey);
        await cache.RemoveAsync($"products:{id}");

        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        var product = await db.Products.FindAsync(id);

        if (product is null)
            return NotFound();

        db.Products.Remove(product);
        await db.SaveChangesAsync();
        await cache.RemoveAsync(ProductsCacheKey);
        await cache.RemoveAsync($"products:{id}");

        return NoContent();
    }
}
