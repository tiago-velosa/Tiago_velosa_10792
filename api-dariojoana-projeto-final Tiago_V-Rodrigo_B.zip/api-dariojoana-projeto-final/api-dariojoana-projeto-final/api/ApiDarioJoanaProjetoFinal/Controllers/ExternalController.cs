using ApiDarioJoanaProjetoFinal.Models;
using ApiDarioJoanaProjetoFinal.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApiDarioJoanaProjetoFinal.Controllers;

[ApiController]
[Route("api")]
[Authorize]
public class ExternalController(IExternalInventoryService externalService) : ControllerBase
{
    [HttpGet("inventory/{sku}")]
    public async Task<IActionResult> GetInventory(string sku)
    {
        var result = await externalService.GetInventoryAsync(sku);
        return Content(result, "application/json");
    }

    [HttpPost("payments")]
    public async Task<IActionResult> CreatePayment(PaymentRequest request)
    {
        var result = await externalService.CreatePaymentAsync(request);
        return Content(result, "application/json");
    }
}
