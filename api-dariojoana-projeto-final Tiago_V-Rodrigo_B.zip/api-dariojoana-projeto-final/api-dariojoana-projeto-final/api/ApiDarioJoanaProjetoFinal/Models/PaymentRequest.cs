namespace ApiDarioJoanaProjetoFinal.Models;

public class PaymentRequest
{
    public int UserId { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "EUR";
    public string PaymentMethod { get; set; } = "card";
}
