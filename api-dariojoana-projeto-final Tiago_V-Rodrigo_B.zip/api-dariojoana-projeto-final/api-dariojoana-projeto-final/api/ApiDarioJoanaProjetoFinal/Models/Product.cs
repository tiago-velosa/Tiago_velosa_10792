using System.ComponentModel.DataAnnotations;

namespace ApiDarioJoanaProjetoFinal.Models;

public class Product
{
    public int Id { get; set; }

    [Required, MaxLength(80)]
    public string Sku { get; set; } = string.Empty;

    [Required, MaxLength(160)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(500)]
    public string Description { get; set; } = string.Empty;

    [Range(0.01, 999999)]
    public decimal Price { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
