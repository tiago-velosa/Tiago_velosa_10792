using System.Text;
using System.Text.Json;
using ApiDarioJoanaProjetoFinal.Models;

namespace ApiDarioJoanaProjetoFinal.Services;

public interface IExternalInventoryService
{
    Task<string> GetInventoryAsync(string sku);
    Task<string> CreatePaymentAsync(PaymentRequest request);
}

public class ExternalInventoryService(HttpClient httpClient) : IExternalInventoryService
{
    public async Task<string> GetInventoryAsync(string sku)
    {
        var response = await httpClient.GetAsync($"/inventory/{sku}");

        if (!response.IsSuccessStatusCode)
            return JsonSerializer.Serialize(new { sku, available = false, message = "Serviço de inventário indisponível" });

        return await response.Content.ReadAsStringAsync();
    }

    public async Task<string> CreatePaymentAsync(PaymentRequest request)
    {
        var json = JsonSerializer.Serialize(request);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await httpClient.PostAsync("/payments", content);

        if (!response.IsSuccessStatusCode)
            return JsonSerializer.Serialize(new { approved = false, message = "Serviço de pagamentos indisponível" });

        return await response.Content.ReadAsStringAsync();
    }
}
