namespace ApiDarioJoanaProjetoFinal.Dtos;

public record ProductCreateDto(string Sku, string Name, string Description, decimal Price);
public record ProductUpdateDto(string Name, string Description, decimal Price, bool IsActive);
