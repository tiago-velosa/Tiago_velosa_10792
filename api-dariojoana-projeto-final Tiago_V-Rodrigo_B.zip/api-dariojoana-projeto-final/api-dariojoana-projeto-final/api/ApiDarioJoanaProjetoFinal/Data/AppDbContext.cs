using ApiDarioJoanaProjetoFinal.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiDarioJoanaProjetoFinal.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Product> Products => Set<Product>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>()
            .HasIndex(u => u.Email)
            .IsUnique();

        modelBuilder.Entity<Product>()
            .HasIndex(p => p.Sku)
            .IsUnique();

        modelBuilder.Entity<Product>()
            .Property(p => p.Price)
            .HasPrecision(10, 2);

        modelBuilder.Entity<User>().HasData(
            new User
            {
                Id = 1,
                Name = "Administrador",
                Email = "admin@projeto.pt",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin123!"),
                Role = "Admin",
                CreatedAt = new DateTime(2026, 5, 1, 0, 0, 0, DateTimeKind.Utc)
            }
        );

        modelBuilder.Entity<Product>().HasData(
            new Product { Id = 1, Sku = "LAPTOP-001", Name = "Computador Portátil", Description = "Portátil para trabalho académico", Price = 799.99m, IsActive = true, CreatedAt = new DateTime(2026, 5, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Product { Id = 2, Sku = "MOUSE-001", Name = "Rato sem fios", Description = "Rato ergonómico", Price = 19.99m, IsActive = true, CreatedAt = new DateTime(2026, 5, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Product { Id = 3, Sku = "KEYBOARD-001", Name = "Teclado mecânico", Description = "Teclado PT com retroiluminação", Price = 59.99m, IsActive = true, CreatedAt = new DateTime(2026, 5, 1, 0, 0, 0, DateTimeKind.Utc) }
        );
    }
}
