INSERT INTO "Users" ("Name", "Email", "PasswordHash", "Role", "CreatedAt")
VALUES
('Administrador', 'admin@projeto.pt', '$2a$11$Vt5QKhyMbP2mZKdy1LW/4u6DpVNnyXxzQFcPKTnlJHPXm7T3ns5kW', 'Admin', NOW())
ON CONFLICT ("Email") DO NOTHING;

INSERT INTO "Products" ("Sku", "Name", "Description", "Price", "IsActive", "CreatedAt")
VALUES
('LAPTOP-001', 'Computador Portátil', 'Portátil para trabalho académico', 799.99, TRUE, NOW()),
('MOUSE-001', 'Rato sem fios', 'Rato ergonómico', 19.99, TRUE, NOW()),
('KEYBOARD-001', 'Teclado mecânico', 'Teclado PT com retroiluminação', 59.99, TRUE, NOW())
ON CONFLICT ("Sku") DO NOTHING;
