### Como executar o código ###

- Em primeiro lugar deve ter o Docker instalado e Abri-lo
- Abra a pasta com o trabalho no vscode

- No terminal navegue até neste diretório C:\Users\HP\Downloads\api-dariojoana-projeto-final\api-dariojoana-projeto-final\api\ApiDarioJoanaProjetoFinal
Com os comandos:

cd api-dariojoana-projeto-final 
cd api
cd ApiDarioJoanaProjetoFinal

- Já na respetiva pasta digite este comando: docker compose up --build
- Quando terminar de executar, abra no seu browser: http://localhost:8080/swagger

### Informações adicionais ###
- Lembrando que a porta 8080 deve estar livre para o programa executar corretamente
- E o docker deve estar aberto